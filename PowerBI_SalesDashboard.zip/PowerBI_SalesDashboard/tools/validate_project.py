"""
validate_project.py
===================
Validates the generated PBIP project against Microsoft's official JSON schemas
and checks that every field referenced by the report actually exists in the
semantic model.

  python tools/validate_project.py
"""

from __future__ import annotations

import base64
import glob
import json
import os
import re
import urllib.error
import urllib.request

from jsonschema import Draft7Validator

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCHEMA_DIR = os.path.join(HERE, ".schemas")
os.makedirs(SCHEMA_DIR, exist_ok=True)

REPORT = os.path.join(ROOT, "PowerBI_SalesDashboard.Report")
MODEL = os.path.join(ROOT, "PowerBI_SalesDashboard.SemanticModel")

BASE = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/"

SCHEMAS = {
    "visualContainer-2.9.0": BASE + "visualContainer/2.9.0/schema.json",
    "report-3.3.0": BASE + "report/3.3.0/schema.json",
    "page-2.1.0": BASE + "page/2.1.0/schema.json",
    "pagesMetadata-1.0.0": BASE + "pagesMetadata/1.0.0/schema.json",
    "versionMetadata-1.0.0": BASE + "versionMetadata/1.0.0/schema.json",
    "definitionProperties-report-2.0.0":
        "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
    "definitionProperties-semanticModel-1.0.0":
        "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
    "platformProperties-2.0.0":
        "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
    "pbipProperties-1.0.0":
        "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
}


def fetch_schemas():
    out = {}
    for name, url in SCHEMAS.items():
        path = os.path.join(SCHEMA_DIR, name + ".json")
        if not os.path.exists(path):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = r.read()
                with open(path, "wb") as h:
                    h.write(data)
            except Exception as e:
                print(f"  ! cannot fetch {name}: {e}")
                continue
        with open(path, encoding="utf-8") as h:
            out[name] = json.load(h)
    return out


def main():
    schemas = fetch_schemas()
    errors, checked = [], 0

    def validate(path, schema_name, label):
        nonlocal checked
        if schema_name not in schemas or not os.path.exists(path):
            return
        with open(path, encoding="utf-8") as h:
            doc = json.load(h)
        for e in Draft7Validator(schemas[schema_name]).iter_errors(doc):
            errors.append(f"{label} :: {list(e.absolute_path)} :: {e.message}")
        checked += 1

    validate(os.path.join(REPORT, "definition", "report.json"), "report-3.3.0", "report.json")
    validate(os.path.join(REPORT, "definition", "pages", "pages.json"), "pagesMetadata-1.0.0", "pages.json")
    validate(os.path.join(REPORT, "definition", "version.json"), "versionMetadata-1.0.0", "version.json")
    validate(os.path.join(REPORT, "definition.pbir"), "definitionProperties-report-2.0.0", "definition.pbir")
    validate(os.path.join(REPORT, ".platform"), "platformProperties-2.0.0", "Report/.platform")
    validate(os.path.join(MODEL, ".platform"), "platformProperties-2.0.0", "SemanticModel/.platform")
    validate(os.path.join(MODEL, "definition.pbism"), "definitionProperties-semanticModel-1.0.0", "definition.pbism")
    validate(os.path.join(ROOT, "PowerBI_SalesDashboard.pbip"), "pbipProperties-1.0.0", "pbip")

    for pj in sorted(glob.glob(os.path.join(REPORT, "definition", "pages", "*", "page.json"))):
        validate(pj, "page-2.1.0", os.path.relpath(pj, ROOT))

    vis_files = sorted(glob.glob(os.path.join(REPORT, "definition", "pages", "*", "visuals", "*", "visual.json")))
    for vj in vis_files:
        validate(vj, "visualContainer-2.9.0", os.path.relpath(vj, ROOT))

    print(f"=== schema validation: {checked} files checked, {len(errors)} errors ===")
    for e in errors[:40]:
        print("  ERR", e)

    with open(os.path.join(MODEL, "model.bim"), encoding="utf-8") as h:
        bim = json.load(h)
    model = bim["model"]
    tables = {t["name"]: t for t in model["tables"]}
    columns = {n: {c["name"] for c in t.get("columns", [])} for n, t in tables.items()}
    measures = {n: {x["name"] for x in t.get("measures", [])} for n, t in tables.items()}

    print("\n=== model.bim ===")
    print("compatibilityLevel:", bim.get("compatibilityLevel"))
    print("tables:", list(tables))
    print("relationships:", [(r["fromTable"], r["fromColumn"], "->", r["toTable"], r["toColumn"])
                              for r in model["relationships"]])

    ok = True
    for name, t in tables.items():
        for part in t.get("partitions", []):
            blob = None
            for line in part["source"]["expression"]:
                m = re.search(r'Binary\.FromText\("([A-Za-z0-9+/=]+)"', line)
                if m:
                    blob = m.group(1)
            if blob is None:
                print(f"  !! {name}: no base64 payload")
                ok = False
                continue
            raw = base64.b64decode(blob).decode("utf-8")
            lines = raw.strip().split("\n")
            ncols = len(lines[0].split(","))
            ragged = sum(1 for l in lines if l.count(",") != ncols - 1)
            print(f"  {name:<10} rows={len(lines)-1:<5} cols={ncols:<3} ragged={ragged}")
            if ragged:
                ok = False

    ref_errors = []

    def scan(node, fname):
        if isinstance(node, dict):
            sr = node.get("SourceRef")
            if isinstance(sr, dict) and "Entity" in sr:
                ent, prop = sr["Entity"], node.get("Property")
                if ent not in tables:
                    ref_errors.append(f"{fname}: unknown entity {ent!r}")
                elif prop is not None and prop not in columns[ent] and prop not in measures[ent]:
                    ref_errors.append(f"{fname}: {ent}.{prop!r} not found")
            for v in node.values():
                scan(v, fname)
        elif isinstance(node, list):
            for v in node:
                scan(v, fname)

    for vj in vis_files:
        with open(vj, encoding="utf-8") as h:
            scan(json.load(h), os.path.basename(os.path.dirname(vj)))

    print(f"\n=== PBIR -> model reference check: {len(ref_errors)} problems ===")
    for e in ref_errors[:40]:
        print("  ERR", e)

    result = "PASS" if not errors and not ref_errors and ok else "FAIL"
    print("\nRESULT:", result)
    return 0 if result == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
