"""
build_preview.py
================
Builds a standalone offline HTML preview of the dashboard from the cleaned
CSV files in /data. It mirrors the four Power BI pages and is used to verify
every number the Power BI model will show (the preview and the model read the
same source, so any divergence shows up immediately).

  python tools/build_preview.py
"""

from __future__ import annotations

import html
import json
import os

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "preview", "dashboard_preview.html")

C_ORDER, C_DATE, C_PROD, C_CITY = "رقم الطلب", "تاريخ الطلب", "المنتج", "المدينة"
C_QTY, C_PRICE, C_SALES, C_PROFIT = "الكمية", "سعر الوحدة", "إجمالي المبيعات", "الأرباح"
C_GROSS, C_FACTOR, C_STATUS = "القيمة الاسمية", "معامل التسعير", "حالة التسعير"
C_CATEGORY, C_GOV = "الفئة", "المحافظة"

PALETTE = ["#1F6FEB", "#2DA44E", "#BF8700", "#CF222E", "#8250DF", "#1B7C83"]


def fmt(n, dec=0):
    return f"{n:,.{dec}f}"


def pct(n):
    return f"{n:.1%}"


# --------------------------------------------------------------------------
# SVG chart primitives
# --------------------------------------------------------------------------


def svg_line(cats, series, width=1000, height=420, y_fmt=fmt):
    """series: list of (name, values)"""
    pad_l, pad_r, pad_t, pad_b = 70, 24, 30, 70
    w, h = width - pad_l - pad_r, height - pad_t - pad_b
    allv = [v for _, vals in series for v in vals]
    mx = max(allv) * 1.1 or 1
    mn = 0
    n = len(cats)
    step = w / max(n - 1, 1)

    def X(i):
        return pad_l + i * step

    def Y(v):
        return pad_t + h - (v - mn) / (mx - mn) * h

    out = [f'<svg viewBox="0 0 {width} {height}" class="chart" preserveAspectRatio="none">']
    for k in range(6):
        yv = mn + (mx - mn) * k / 5
        y = Y(yv)
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{pad_l+w}" y2="{y:.1f}" class="grid"/>')
        out.append(f'<text x="{pad_l-10}" y="{y+4:.1f}" class="axlbl" text-anchor="end">{y_fmt(yv)}</text>')
    for i, c in enumerate(cats):
        if i % max(1, n // 8) == 0 or i == n - 1:
            out.append(f'<text x="{X(i):.1f}" y="{pad_t+h+22}" class="axlbl" text-anchor="middle">{c}</text>')
    for si, (name, vals) in enumerate(series):
        col = PALETTE[si % len(PALETTE)]
        pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(vals))
        out.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="2.5"/>')
        for i, v in enumerate(vals):
            out.append(f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="3" fill="{col}"/>')
    out.append("</svg>")
    return "".join(out)


def svg_bar(cats, series, width=620, height=300, y_fmt=fmt, labels=True):
    rotate = len(cats) >= 7
    pad_l, pad_r, pad_t, pad_b = (70, 20, 20, 120 if rotate else 70)
    w, h = width - pad_l - pad_r, height - pad_t - pad_b
    allv = [v for _, vals in series for v in vals]
    mx = max(allv) * 1.12 or 1
    n = len(cats)
    ns = len(series)
    slot = w / max(n, 1)
    bw = slot * 0.72 / ns

    def Y(v):
        return pad_t + h - v / mx * h

    out = [f'<svg viewBox="0 0 {width} {height}" class="chart" preserveAspectRatio="none">']
    for k in range(5):
        yv = mx * k / 4
        y = Y(yv)
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{pad_l+w}" y2="{y:.1f}" class="grid"/>')
        out.append(f'<text x="{pad_l-10}" y="{y+4:.1f}" class="axlbl" text-anchor="end">{y_fmt(yv)}</text>')
    for i, c in enumerate(cats):
        x0 = pad_l + i * slot + slot * 0.14
        for si, (name, vals) in enumerate(series):
            v = vals[i]
            y = Y(v)
            col = PALETTE[si % len(PALETTE)]
            out.append(f'<rect x="{x0+si*bw:.1f}" y="{y:.1f}" width="{bw*0.88:.1f}" '
                       f'height="{pad_t+h-y:.1f}" fill="{col}" rx="2"/>')
            if labels and ns == 1:
                out.append(f'<text x="{x0+bw/2:.1f}" y="{y-5:.1f}" class="datalbl" '
                           f'text-anchor="middle">{y_fmt(v)}</text>')
        out.append(f'<text x="{pad_l+i*slot+slot/2:.1f}" y="{pad_t+h+20}" class="axlbl" '
                   f'text-anchor="middle"'
                   + (f' transform="rotate(-38 {pad_l+i*slot+slot/2:.1f} {pad_t+h+20})"' if rotate else '')
                   + f'>{html.escape(str(c))}</text>')
    out.append("</svg>")
    return "".join(out)


def svg_hbar(cats, vals, width=620, height=300, color="#1F6FEB", y_fmt=fmt):
    pad_l, pad_r, pad_t, pad_b = 130, 70, 14, 14
    w, h = width - pad_l - pad_r, height - pad_t - pad_b
    mx = max(vals) * 1.08 or 1
    rowh = h / max(len(cats), 1)
    out = [f'<svg viewBox="0 0 {width} {height}" class="chart" preserveAspectRatio="none">']
    for i, (c, v) in enumerate(zip(cats, vals)):
        y = pad_t + i * rowh + rowh * 0.18
        bh = rowh * 0.64
        bw = v / mx * w
        out.append(f'<rect x="{pad_l}" y="{y:.1f}" width="{bw:.1f}" height="{bh:.1f}" fill="{color}" rx="3"/>')
        out.append(f'<text x="{pad_l-10}" y="{y+bh*0.72:.1f}" class="axlbl" text-anchor="end">'
                   f'{html.escape(str(c))}</text>')
        out.append(f'<text x="{pad_l+bw+8:.1f}" y="{y+bh*0.72:.1f}" class="datalbl">{y_fmt(v)}</text>')
    out.append("</svg>")
    return "".join(out)


def table(headers, rows):
    h = "".join(f"<th>{html.escape(str(x))}</th>" for x in headers)
    b = "".join("<tr>" + "".join(f"<td>{x}</td>" for x in r) + "</tr>" for r in rows)
    return f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"


def kpi(label, value, sub=""):
    return (f'<div class="kpi"><div class="kpi-l">{html.escape(label)}</div>'
            f'<div class="kpi-v">{value}</div>'
            f'<div class="kpi-s">{html.escape(sub)}</div></div>')


def panel(title, body, cls=""):
    return (f'<section class="panel {cls}"><h3>{html.escape(title)}</h3>{body}</section>')


def legend(names):
    items = "".join(f'<span class="lg"><i style="background:{PALETTE[i%len(PALETTE)]}"></i>'
                     f'{html.escape(n)}</span>' for i, n in enumerate(names))
    return f'<div class="legend">{items}</div>'


# --------------------------------------------------------------------------
# Build
# --------------------------------------------------------------------------


def main():
    f = pd.read_csv(os.path.join(DATA, "sales.csv"), encoding="utf-8-sig")
    p = pd.read_csv(os.path.join(DATA, "products.csv"), encoding="utf-8-sig")
    c = pd.read_csv(os.path.join(DATA, "cities.csv"), encoding="utf-8-sig")

    f[C_DATE] = pd.to_datetime(f[C_DATE])
    f["ym"] = f[C_DATE].dt.strftime("%Y-%m")
    f = f.merge(p, on=C_PROD, how="left").merge(c, on=C_CITY, how="left")

    total_sales = f[C_SALES].sum()
    total_profit = f[C_PROFIT].sum()
    total_qty = f[C_QTY].sum()
    orders = len(f)
    margin = total_profit / total_sales
    avg_order = total_sales / orders
    gross = f[C_GROSS].sum()

    months = sorted(f["ym"].unique())
    m_sales = [f.loc[f["ym"] == m, C_SALES].sum() for m in months]
    m_profit = [f.loc[f["ym"] == m, C_PROFIT].sum() for m in months]
    m_gross = [f.loc[f["ym"] == m, C_GROSS].sum() for m in months]
    m_avgfac = [f.loc[f["ym"] == m, C_FACTOR].mean() for m in months]

    city_sales = f.groupby(C_CITY)[C_SALES].sum().sort_values(ascending=False)
    city_profit = f.groupby(C_CITY)[C_PROFIT].sum().reindex(city_sales.index)
    prod_sales = f.groupby(C_PROD)[C_SALES].sum().sort_values(ascending=False)
    prod_profit = f.groupby(C_PROD)[C_PROFIT].sum().reindex(prod_sales.index)
    prod_margin = (prod_profit / prod_sales).sort_values(ascending=False)
    status_counts = f[C_STATUS].value_counts()

    # ---------------- overview ----------------
    kpis = "".join([
        kpi("إجمالي المبيعات", fmt(total_sales), f"{len(months)} شهر"),
        kpi("إجمالي الأرباح", fmt(total_profit), "مجموع الأرباح"),
        kpi("هامش الربح", pct(margin), "الأرباح ÷ المبيعات"),
        kpi("عدد الطلبات", fmt(orders), f"{f[C_PROD].nunique()} منتجات · {f[C_CITY].nunique()} مدن"),
        kpi("متوسط قيمة الطلب", fmt(avg_order, 1), f"الكمية المباعة {fmt(total_qty)}"),
    ])
    overview = f"""
    <div class="kpis">{kpis}</div>
    <div class="grid2">
      {panel("المبيعات والأرباح شهرياً",
             svg_line(months, [("المبيعات", m_sales), ("الأرباح", m_profit)], 1000, 420)
             + legend(["المبيعات", "الأرباح"]), "wide")}
      {panel("المبيعات حسب المدينة",
             svg_hbar(list(city_sales.index), list(city_sales.values), 620, 420))}
    </div>
    """

    # ---------------- products ----------------
    prod_rows = []
    for prod in prod_sales.index:
        sub = f[f[C_PROD] == prod]
        prod_rows.append([
            html.escape(prod), html.escape(sub[C_CATEGORY].iloc[0]),
            fmt(sub[C_SALES].sum()), fmt(sub[C_PROFIT].sum()),
            pct(sub[C_PROFIT].sum() / sub[C_SALES].sum()),
            fmt(sub[C_QTY].sum()), fmt(len(sub))])
    products = f"""
    <div class="grid2">
      {panel("المبيعات والأرباح حسب المنتج",
             svg_bar(list(prod_sales.index), [("المبيعات", list(prod_sales.values)),
                                             ("الأرباح", list(prod_profit.values))], 760, 320)
             + legend(["المبيعات", "الأرباح"]))}
      {panel("هامش الربح حسب المنتج",
             svg_hbar(list(prod_margin.index), list(prod_margin.values), 620, 320, color="#2DA44E",
                      y_fmt=lambda v: f"{v:.1%}"))}
    </div>
    {panel("تفاصيل المنتجات",
           table(["المنتج", "الفئة", "المبيعات", "الأرباح", "هامش الربح", "الكمية", "الطلبات"],
                 prod_rows), "wide")}
    """

    # ---------------- cities ----------------
    city_rows = []
    for city in city_sales.index:
        sub = f[f[C_CITY] == city]
        city_rows.append([html.escape(city), html.escape(sub[C_GOV].iloc[0]),
                          fmt(sub[C_SALES].sum()), fmt(sub[C_PROFIT].sum()),
                          pct(sub[C_PROFIT].sum() / sub[C_SALES].sum()), fmt(len(sub))])
    cities_trend = {}
    for city in city_sales.index:
        cities_trend[city] = [f.loc[(f["ym"] == m) & (f[C_CITY] == city), C_SALES].sum() for m in months]
    cities = f"""
    <div class="grid2">
      {panel("المبيعات حسب المدينة",
             svg_bar(list(city_sales.index), [("المبيعات", list(city_sales.values))], 760, 320))}
      {panel("الأرباح حسب المدينة",
             svg_hbar(list(city_profit.index), list(city_profit.values), 620, 320, color="#2DA44E"))}
    </div>
    {panel("اتجاه المبيعات الشهري لكل مدينة",
           svg_line(months, [(city, cities_trend[city]) for city in city_sales.index], 1000, 400)
           + legend(list(city_sales.index)), "wide")}
    {panel("تفاصيل المدن",
           table(["المدينة", "المحافظة", "المبيعات", "الأرباح", "هامش الربح", "الطلبات"], city_rows), "wide")}
    """

    # ---------------- data quality ----------------
    st_order = ["سعر عادي", "خصم", "زيادة"]
    st_counts = [int(status_counts.get(s, 0)) for s in st_order]
    dq_rows = []
    for _, r in f.sort_values(C_ORDER).iterrows():
        dq_rows.append([
            fmt(r[C_ORDER]), r[C_DATE].strftime("%Y-%m-%d"), html.escape(r[C_PROD]),
            html.escape(r[C_CITY]), fmt(r[C_QTY]), fmt(r[C_PRICE], 2), fmt(r[C_GROSS], 2),
            fmt(r[C_SALES], 2), fmt(r[C_PROFIT], 2), f"{r[C_FACTOR]:.2f}", html.escape(r[C_STATUS])])
    dq = f"""
    <div class="note">
      إجمالي المبيعات لا يساوي دائماً (الكمية × سعر الوحدة):
      <b>{int(status_counts.get('خصم',0))}</b> طلباً في 2023-08 تُسعَّر بنسبة 45% من القيمة الاسمية (خصم)،
      و<b>{int(status_counts.get('زيادة',0))}</b> طلباً في 2023-03 بنسبة 135% (زيادة).
      الأنماط شهرية ومنتظمة وليست أخطاء عشوائية.
    </div>
    <div class="grid3">
      {panel("عدد الطلبات حسب حالة التسعير",
             svg_bar(st_order, [("الطلبات", st_counts)], 500, 280))}
      {panel("متوسط معامل التسعير شهرياً",
             svg_line(months, [("المعامل", m_avgfac)], 500, 280,
                      y_fmt=lambda v: f"{v:.2f}"))}
      {panel("القيمة الاسمية مقابل المبيعات",
             svg_line(months, [("القيمة الاسمية", m_gross), ("المبيعات", m_sales)], 500, 280)
             + legend(["القيمة الاسمية", "المبيعات"]))}
    </div>
    {panel("تفاصيل الطلبات",
           table(["رقم الطلب", "التاريخ", "المنتج", "المدينة", "الكمية", "سعر الوحدة",
                  "القيمة الاسمية", "المبيعات", "الأرباح", "المعامل", "الحالة"], dq_rows), "wide scroll")}
    """

    pages = [("نظرة عامة", overview), ("تحليل المنتجات", products),
             ("تحليل المدن", cities), ("جودة البيانات والتسعير", dq)]

    nav = "".join(f'<button data-i="{i}">{html.escape(n)}</button>' for i, (n, _) in enumerate(pages))
    body = "".join(f'<div class="page" id="p{i}" {"hidden" if i else ""}>{b}</div>'
                   for i, (_, b) in enumerate(pages))

    doc = f"""<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>معاينة لوحة المبيعات</title>
<style>
  :root {{ --bg:#F4F6FA; --panel:#fff; --bd:#D8DEE4; --fg:#1F2328; --mut:#57606A; --acc:#1F6FEB; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--fg);
         font-family:"Segoe UI","Tahoma",Arial,sans-serif; }}
  header {{ position:sticky; top:0; z-index:9; background:#fff; border-bottom:1px solid var(--bd);
            padding:14px 24px; display:flex; gap:18px; align-items:center; flex-wrap:wrap; }}
  header h1 {{ font-size:20px; margin:0 0 0 14px; }}
  nav button {{ font:inherit; font-size:13px; padding:7px 14px; margin-inline-end:6px;
               border:1px solid var(--bd); background:#fff; border-radius:6px; cursor:pointer; }}
  nav button.on {{ background:var(--acc); color:#fff; border-color:var(--acc); }}
  .wrap {{ padding:20px 24px 48px; max-width:1640px; margin:0 auto; }}
  .kpis {{ display:grid; grid-template-columns:repeat(5,1fr); gap:14px; margin-bottom:16px; }}
  .kpi {{ background:var(--panel); border:1px solid var(--bd); border-radius:10px; padding:14px 16px; }}
  .kpi-l {{ font-size:12px; color:var(--mut); }}
  .kpi-v {{ font-size:30px; font-weight:600; margin:4px 0 2px; }}
  .kpi-s {{ font-size:11px; color:var(--mut); }}
  .grid2 {{ display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px; }}
  .grid3 {{ display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:16px; }}
  .panel {{ background:var(--panel); border:1px solid var(--bd); border-radius:10px; padding:14px 16px;
            margin-bottom:16px; overflow:hidden; }}
  .panel h3 {{ font-size:14px; margin:0 0 10px; font-weight:600; }}
  .chart {{ width:100%; height:auto; display:block; direction:ltr; }}
  .grid {{ stroke:#E4E8ED; stroke-width:1; }}
  .axlbl {{ font-size:11px; fill:#57606A; font-family:Segoe UI,Tahoma,sans-serif; direction:ltr; }}
  .datalbl {{ font-size:10px; fill:#1F2328; font-family:Segoe UI,Tahoma,sans-serif; direction:ltr; }}
  .legend {{ display:flex; gap:16px; flex-wrap:wrap; margin-top:8px; font-size:12px; color:var(--mut); }}
  .lg i {{ display:inline-block; width:11px; height:11px; border-radius:2px; margin-inline-end:5px; }}
  table {{ width:100%; border-collapse:collapse; font-size:12px; }}
  th {{ background:#1F6FEB; color:#fff; text-align:right; padding:7px 9px; font-weight:600; }}
  td {{ padding:6px 9px; border-bottom:1px solid #EEF1F5; }}
  tbody tr:hover {{ background:#F6F9FF; }}
  .scroll {{ max-height:520px; overflow:auto; }}
  .note {{ background:#FFF8E6; border:1px solid #F0D48A; border-radius:10px; padding:12px 16px;
           font-size:13px; margin-bottom:16px; line-height:1.7; }}
  .foot {{ color:var(--mut); font-size:12px; text-align:center; margin-top:26px; line-height:1.8; }}
  @media (max-width:1100px) {{ .kpis {{ grid-template-columns:repeat(2,1fr); }}
    .grid2,.grid3 {{ grid-template-columns:1fr; }} }}
</style>
</head>
<body>
<header>
  <h1>لوحة المبيعات — معاينة</h1>
  <nav>{nav}</nav>
</header>
<div class="wrap">
{body}
  <p class="foot">
    معاينة offline مولّدة من نفس ملفات البيانات المستخدمة في نموذج Power BI — الأرقام مطابقة للنموذج.<br/>
    المشروع الحقيقي: <b>PowerBI_SalesDashboard.pbip</b> — يُفتح في Power BI Desktop.
  </p>
</div>
<script>
  const btns = [...document.querySelectorAll('nav button')];
  const pages = [...document.querySelectorAll('.page')];
  btns.forEach((b,i)=>b.addEventListener('click',()=>{{
    btns.forEach(x=>x.classList.remove('on')); b.classList.add('on');
    pages.forEach((p,j)=>p.hidden = j!==i);
  }}));
  btns[0].classList.add('on');
</script>
</body>
</html>
"""

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(doc)

    summary = {
        "orders": orders, "sales": round(total_sales, 2), "profit": round(total_profit, 2),
        "margin": round(margin, 6), "avg_order": round(avg_order, 2),
        "qty": int(total_qty), "gross": round(gross, 2),
        "products": int(f[C_PROD].nunique()), "cities": int(f[C_CITY].nunique()),
        "months": len(months),
        "city_sales": {k: round(v, 2) for k, v in city_sales.items()},
        "prod_sales": {k: round(v, 2) for k, v in prod_sales.items()},
        "status": {s: int(status_counts.get(s, 0)) for s in st_order},
        "monthly_sales": {m: round(v, 2) for m, v in zip(months, m_sales)},
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print("written:", OUT, os.path.getsize(OUT), "bytes")


if __name__ == "__main__":
    main()
