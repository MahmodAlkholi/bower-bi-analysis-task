"""
build_pbi_project.py
====================
Generates a complete, self-contained Power BI Project (PBIP) from the sales
Excel file.

Outputs
-------
  <root>/PowerBI_SalesDashboard.pbip
  <root>/PowerBI_SalesDashboard.SemanticModel/{.platform, definition.pbism, model.bim}
  <root>/PowerBI_SalesDashboard.Report/{.platform, definition.pbir, definition/...}
  <root>/data/*.csv
  <root>/README.md

The data is embedded in the semantic model as Base64 CSV (Binary.FromText),
so the project is fully portable: no file paths to remap, nothing to configure.
The plain CSVs in /data are kept for inspection and for users who prefer a
file-based data source.

Usage
-----
  python tools/build_pbi_project.py --source "data.xlsx" [--scope all]
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os

import pandas as pd

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_ROOT = os.path.dirname(HERE)

PROJECT = "PowerBI_SalesDashboard"
REPORT_DIR = f"{PROJECT}.Report"
MODEL_DIR = f"{PROJECT}.SemanticModel"

SCHEMA_VISUAL = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.9.0/schema.json"
SCHEMA_PAGE = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json"
SCHEMA_REPORT = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json"
SCHEMA_PAGES = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json"
SCHEMA_VERSION = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json"
SCHEMA_PBIR = "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json"
SCHEMA_PBISM = "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json"
SCHEMA_PLATFORM = "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json"
SCHEMA_PBIP = "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json"

THEME_NAME = "SalesDashboardTheme-3f7a21c9.json"

PAGE_W, PAGE_H = 1600, 900

# Model names (Arabic, matching the source workbook headers)
T_SALES, T_DATE, T_PROD, T_CITY, T_MEAS = "المبيعات", "التاريخ", "المنتجات", "المدن", "المقاييس"

C_ORDER, C_DATE, C_PROD, C_CITY = "رقم الطلب", "تاريخ الطلب", "المنتج", "المدينة"
C_QTY, C_PRICE, C_SALES, C_PROFIT = "الكمية", "سعر الوحدة", "إجمالي المبيعات", "الأرباح"
C_GROSS, C_FACTOR, C_STATUS = "القيمة الاسمية", "معامل التسعير", "حالة التسعير"
C_YEAR, C_QUARTER, C_MONTH = "السنة", "الربع", "الشهر"
C_MONTHNAME, C_YEARMONTH = "اسم الشهر", "السنة والشهر"
C_CATEGORY, C_GOV = "الفئة", "المحافظة"

STATUS_NORMAL, STATUS_DISCOUNT, STATUS_MARKUP = "سعر عادي", "خصم", "زيادة"

# Derived product taxonomy (documented in README)
PRODUCT_CATEGORY = {
    "فوط مطبخ": "أدوات المطبخ",
    "منظم أدراج": "أدوات المطبخ",
    "ممسحة أرضيات": "أدوات التنظيف",
    "قماشة تنظيف": "أدوات التنظيف",
    "سلة قمامة صغيرة": "أدوات التنظيف",
    "مناديل ورقية": "المناديل",
    "مناديل معطرة": "المناديل",
    "بخاخ معطر": "المعطرات والمطهرات",
    "بخاخ مطهر": "المعطرات والمطهرات",
    "عطر منزلي": "المعطرات والمطهرات",
}

# Factual governorate mapping
CITY_GOVERNORATE = {
    "القاهرة": "القاهرة",
    "الجيزة": "الجيزة",
    "الإسكندرية": "الإسكندرية",
    "المنصورة": "الدقهلية",
    "أسيوط": "أسيوط",
    "بنها": "البحيرة",
}

MONTH_NAMES_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
                  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]

THEME = {
    "name": THEME_NAME,
    "dataColors": ["#1F6FEB", "#2DA44E", "#BF8700", "#CF222E",
                   "#8250DF", "#1B7C83", "#9A6700", "#DB61A2"],
    "background": "#F4F6FA",
    "foreground": "#1F2328",
    "tableAccent": "#1F6FEB",
    "good": "#1A7F37",
    "bad": "#CF222E",
    "neutral": "#656D76",
    "textClasses": {
        "title": {"fontFace": "Segoe UI Semibold", "fontSize": 13, "color": "#1F2328"},
        "label": {"fontFace": "Segoe UI", "fontSize": 10, "color": "#57606A"},
        "callout": {"fontFace": "Segoe UI Semibold", "fontSize": 28, "color": "#1F2328"},
    },
}

PAGE_BG, PAGE_OUTSPACE = "#F4F6FA", "#FFFFFF"
CARD_BG, CARD_BORDER = "#FFFFFF", "#D8DEE4"
ACCENT = "#1F6FEB"

# --------------------------------------------------------------------------
# Low-level helpers
# --------------------------------------------------------------------------


def w(path: str, content: str) -> None:
    """Write UTF-8 without BOM (required for PBIP/PBIR text files)."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def wj(path: str, obj) -> None:
    w(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def vid(*parts: str) -> str:
    """Deterministic 20-hex-char visual id."""
    return hashlib.sha1("::".join(parts).encode("utf-8")).hexdigest()[:20]


def b64_csv(df: pd.DataFrame) -> str:
    return base64.b64encode(df.to_csv(index=False, lineterminator="\n").encode("utf-8")).decode("ascii")


def csv_partition(table_name: str, df: pd.DataFrame, types: list[tuple[str, str]]) -> dict:
    """Proven M pattern: Base64 CSV -> Csv.Document -> PromoteHeaders -> TransformColumnTypes."""
    type_expr = ", ".join('{{"{0}", {1}}}'.format(c, t) for c, t in types)
    expr = [
        "let",
        '    Binary = Binary.FromText("{0}", BinaryEncoding.Base64),'.format(b64_csv(df)),
        '    Source = Csv.Document(Binary, [Delimiter=",", Columns={0}, Encoding=65001, QuoteStyle=QuoteStyle.Csv]),'.format(len(df.columns)),
        "    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),",
        '    Typed = Table.TransformColumnTypes(Promoted, {{{0}}}, "en-US")'.format(type_expr),
        "in",
        "    Typed",
    ]
    return {"name": table_name, "mode": "import",
            "source": {"type": "m", "expression": expr}}


def col(name, dtype, source=None, fmt=None, key=False, hidden=False):
    c = {"name": name, "dataType": dtype, "sourceColumn": source or name}
    if fmt:
        c["formatString"] = fmt
    if key:
        c["isKey"] = True
    if hidden:
        c["isHidden"] = True
    return c


def measure(name, expr, fmt=None, folder=None):
    m = {"name": name, "expression": expr}
    if fmt:
        m["formatString"] = fmt
    if folder:
        m["displayFolder"] = folder
    return m


# --------------------------------------------------------------------------
# PBIR helpers
# --------------------------------------------------------------------------


def f_col(entity, prop):
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def f_meas(entity, prop):
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def proj(field, entity, prop, active=False):
    p = {"field": field, "queryRef": f"{entity}.{prop}", "nativeQueryRef": prop}
    if active:
        p["active"] = True
    return p


def lit(value, dtype=None):
    if isinstance(value, str):
        v = "'" + value.replace("'", "''") + "'"
    elif isinstance(value, bool):
        v = "true" if value else "false"
    elif isinstance(value, (int, float)):
        v = str(value)
    else:
        v = f"'{value}'"
    if dtype:
        v += dtype
    return {"expr": {"Literal": {"Value": v}}}


def solid(color):
    return {"solid": {"color": lit(color)}}


def props(**kw):
    return kw


# --------------------------------------------------------------------------
# Visual builders
# --------------------------------------------------------------------------


def vco_title(text, size=13, color="#1F2328"):
    return [{"properties": {
        "show": lit(True),
        "text": lit(text),
        "fontSize": lit(size, "D"),
        "fontColor": solid(color),
        "titleWrap": lit(True),
    }}]


def vco_panel(title=None, title_size=13):
    d = {
        "background": [{"properties": {"show": lit(True), "color": solid(CARD_BG),
                                       "transparency": lit(0, "D")}}],
        "border": [{"properties": {"show": lit(True), "color": solid(CARD_BORDER),
                                   "radius": lit(8, "D")}}],
        "padding": [{"properties": {"top": lit(6, "D"), "bottom": lit(6, "D"),
                                    "left": lit(8, "D"), "right": lit(8, "D")}}],
    }
    if title:
        d["title"] = vco_title(title, title_size)
    return d


def para(text, size=13, bold=False, color="#1F2328", family="Segoe UI", align="right"):
    return {
        "textRuns": [{
            "value": text,
            "textStyle": {
                "fontFamily": family,
                "fontSize": f"{size}px",
                "fontWeight": "bold" if bold else "normal",
                "color": color,
            },
        }],
        "horizontalTextAlignment": align,
    }


def textbox(name, x, y, wd, ht, paragraphs):
    return {
        "$schema": SCHEMA_VISUAL,
        "name": name,
        "position": {"x": x, "y": y, "z": 1000, "height": ht, "width": wd},
        "visual": {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": paragraphs}}]},
            "visualContainerObjects": vco_panel(),
        },
    }


def visual(vtype, name, x, y, wd, ht, query_state=None, z=0, tab=None,
           sort=None, objects=None, panel_title=None):
    v = {
        "$schema": SCHEMA_VISUAL,
        "name": name,
        "position": {"x": x, "y": y, "z": z, "height": ht, "width": wd},
        "visual": {"visualType": vtype},
    }
    if query_state:
        q = {"queryState": query_state}
        if sort:
            q["sortDefinition"] = sort
        v["visual"]["query"] = q
    if objects:
        v["visual"]["objects"] = objects
    v["visual"]["visualContainerObjects"] = vco_panel(panel_title)
    if tab is not None:
        v["position"]["tabOrder"] = tab
    return v


def chart_objects(show_labels=True, show_axis=False, show_legend=False, label_size=10):
    return {
        "labels": [{"properties": {"show": lit(show_labels), "fontSize": lit(label_size, "D")},
                    "selector": {"id": "default"}}],
        "valueAxis": [{"properties": {"show": lit(show_axis)}, "selector": {"id": "default"}}],
        "legend": [{"properties": {"show": lit(show_legend)}, "selector": {"id": "default"}}],
    }


def table_objects(text_size=11):
    return {
        "grid": [{"properties": {"textSize": lit(text_size, "D")}, "selector": {"id": "default"}}],
        "columnHeaders": [{"properties": {"fontColor": solid("#FFFFFF"),
                                          "background": solid(ACCENT)},
                           "selector": {"id": "default"}}],
        "total": [{"properties": {"fontSize": lit(text_size, "D")}, "selector": {"id": "default"}}],
    }


def kpi_card(name, x, y, wd, ht, label, measure_name):
    return visual(
        "cardVisual", name, x, y, wd, ht,
        {"Data": {"projections": [proj(f_meas(T_MEAS, measure_name), T_MEAS, measure_name)]}},
        z=10,
        objects={
            "label": [{"properties": {"show": lit(False)}, "selector": {"id": "default"}}],
            "value": [{"properties": {"fontSize": lit(28, "D"), "bold": lit(True)},
                       "selector": {"id": "default"}}],
        },
        panel_title=label,
    )


def slicer(name, x, y, wd, ht, entity, prop, title):
    return visual(
        "slicer", name, x, y, wd, ht,
        {"Values": {"projections": [proj(f_col(entity, prop), entity, prop, True)]}},
        z=30,
        panel_title=title,
    )


def sort_by_measure(entity, prop, direction="Descending"):
    return {"sort": [{"field": f_meas(entity, prop), "direction": direction}], "isDefaultSort": True}


def sort_by_column(entity, prop, direction="Ascending"):
    return {"sort": [{"field": f_col(entity, prop), "direction": direction}], "isDefaultSort": True}


# --------------------------------------------------------------------------
# Data preparation
# --------------------------------------------------------------------------


def prepare(source: str):
    df = pd.read_excel(source, sheet_name=0, engine="openpyxl")
    df.columns = ["order_no", "order_date", "product", "city", "qty", "unit_price", "sales", "profit"]

    # cleaning rules (documented in README)
    df["product"] = df["product"].astype(str).str.strip()
    df["city"] = df["city"].astype(str).str.strip()
    df["product"] = df["product"].replace({"بخاخة": "بخاخ معطر"})
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    df = df[df["order_date"].notna()].copy()

    df["qty"] = df["qty"].astype(int)
    df["unit_price"] = df["unit_price"].astype(float)
    df["sales"] = df["sales"].astype(float)
    df["profit"] = df["profit"].astype(float)

    df["gross"] = (df["qty"] * df["unit_price"]).round(2)
    df["factor"] = (df["sales"] / df["gross"]).round(4)
    df["status"] = df["factor"].apply(
        lambda f: STATUS_DISCOUNT if f < 0.999 else (STATUS_MARKUP if f > 1.001 else STATUS_NORMAL))
    df["category"] = df["product"].map(PRODUCT_CATEGORY).fillna("أخرى")
    df["governorate"] = df["city"].map(CITY_GOVERNORATE).fillna(df["city"])

    fact = pd.DataFrame({
        C_ORDER: df["order_no"].astype(int),
        C_DATE: df["order_date"].dt.strftime("%Y-%m-%d"),
        C_PROD: df["product"],
        C_CITY: df["city"],
        C_QTY: df["qty"],
        C_PRICE: df["unit_price"],
        C_SALES: df["sales"],
        C_PROFIT: df["profit"],
        C_GROSS: df["gross"],
        C_FACTOR: df["factor"],
        C_STATUS: df["status"],
    })

    products = pd.DataFrame({C_PROD: sorted(df["product"].unique())})
    products[C_CATEGORY] = products[C_PROD].map(PRODUCT_CATEGORY).fillna("أخرى")

    cities = pd.DataFrame({C_CITY: sorted(df["city"].unique())})
    cities[C_GOV] = cities[C_CITY].map(CITY_GOVERNORATE).fillna(cities[C_CITY])

    start, end = df["order_date"].min().normalize(), df["order_date"].max().normalize()
    dd = pd.DataFrame({"d": pd.date_range(start, end, freq="D")})
    dates = pd.DataFrame({
        C_DATE: dd["d"].dt.strftime("%Y-%m-%d"),
        C_YEAR: dd["d"].dt.year.astype(int),
        C_QUARTER: dd["d"].dt.quarter.astype(int),
        C_MONTH: dd["d"].dt.month.astype(int),
        C_MONTHNAME: dd["d"].dt.month.map(lambda m: MONTH_NAMES_AR[m - 1]),
        C_YEARMONTH: dd["d"].dt.strftime("%Y-%m"),
    })

    facts = {
        "orders": int(len(fact)),
        "sales": float(fact[C_SALES].sum()),
        "profit": float(fact[C_PROFIT].sum()),
        "margin": float(fact[C_PROFIT].sum() / fact[C_SALES].sum()),
        "min_date": str(start.date()),
        "max_date": str(end.date()),
        "n_products": int(len(products)),
        "n_cities": int(len(cities)),
        "disc_rows": int((fact[C_STATUS] == STATUS_DISCOUNT).sum()),
        "markup_rows": int((fact[C_STATUS] == STATUS_MARKUP).sum()),
        "normal_rows": int((fact[C_STATUS] == STATUS_NORMAL).sum()),
        "disc_months": fact.loc[fact[C_STATUS] == STATUS_DISCOUNT, C_DATE].str.slice(0, 7).unique().tolist(),
        "markup_months": fact.loc[fact[C_STATUS] == STATUS_MARKUP, C_DATE].str.slice(0, 7).unique().tolist(),
    }
    return fact, products, cities, dates, facts


# --------------------------------------------------------------------------
# Semantic model
# --------------------------------------------------------------------------


def build_model_bim(fact, products, cities, dates) -> dict:
    fact_types = [(C_ORDER, "Int64.Type"), (C_DATE, "type date"), (C_PROD, "type text"),
                  (C_CITY, "type text"), (C_QTY, "Int64.Type"), (C_PRICE, "type number"),
                  (C_SALES, "type number"), (C_PROFIT, "type number"), (C_GROSS, "type number"),
                  (C_FACTOR, "type number"), (C_STATUS, "type text")]
    prod_types = [(C_PROD, "type text"), (C_CATEGORY, "type text")]
    city_types = [(C_CITY, "type text"), (C_GOV, "type text")]
    date_types = [(C_DATE, "type date"), (C_YEAR, "Int64.Type"), (C_QUARTER, "Int64.Type"),
                  (C_MONTH, "Int64.Type"), (C_MONTHNAME, "type text"), (C_YEARMONTH, "type text")]

    measures = [
        measure("عدد الطلبات", f"COUNTROWS('{T_SALES}')", "#,##0", "1. المبيعات"),
        measure("إجمالي المبيعات", f"SUM('{T_SALES}'[{C_SALES}])", "#,##0", "1. المبيعات"),
        measure("إجمالي الأرباح", f"SUM('{T_SALES}'[{C_PROFIT}])", "#,##0", "1. المبيعات"),
        measure("هامش الربح", "DIVIDE([إجمالي الأرباح],[إجمالي المبيعات])", "0.0%", "1. المبيعات"),
        measure("إجمالي الكمية", f"SUM('{T_SALES}'[{C_QTY}])", "#,##0", "1. المبيعات"),
        measure("متوسط قيمة الطلب", "DIVIDE([إجمالي المبيعات],[عدد الطلبات])", "#,##0.00", "1. المبيعات"),
        measure("متوسط سعر الوحدة", "DIVIDE([إجمالي المبيعات],[إجمالي الكمية])", "#,##0.00", "1. المبيعات"),
        measure("القيمة الاسمية الإجمالية",
                f"SUMX('{T_SALES}','{T_SALES}'[{C_QTY}] * '{T_SALES}'[{C_PRICE}])", "#,##0", "2. التسعير"),
        measure("فارق التسعير", "[القيمة الاسمية الإجمالية] - [إجمالي المبيعات]", "#,##0", "2. التسعير"),
        measure("نسبة التسعير", "DIVIDE([إجمالي المبيعات],[القيمة الاسمية الإجمالية])", "0.0%", "2. التسعير"),
        measure("متوسط معامل التسعير", f"AVERAGE('{T_SALES}'[{C_FACTOR}])", "0.00", "2. التسعير"),
        measure("عدد طلبات الخصم",
                f"CALCULATE(COUNTROWS('{T_SALES}'),'{T_SALES}'[{C_STATUS}] = \"{STATUS_DISCOUNT}\")",
                "#,##0", "2. التسعير"),
        measure("مبيعات الخصم",
                f"CALCULATE([إجمالي المبيعات],'{T_SALES}'[{C_STATUS}] = \"{STATUS_DISCOUNT}\")",
                "#,##0", "2. التسعير"),
        measure("عدد المنتجات", f"DISTINCTCOUNT('{T_SALES}'[{C_PROD}])", "#,##0", "3. التغطية"),
        measure("عدد المدن", f"DISTINCTCOUNT('{T_SALES}'[{C_CITY}])", "#,##0", "3. التغطية"),
        measure("نمو المبيعات",
                "VAR Curr = [إجمالي المبيعات]\n"
                f"VAR Prev = CALCULATE([إجمالي المبيعات], DATEADD('{T_DATE}'[{C_DATE}], -1, MONTH))\n"
                "RETURN\n    DIVIDE(Curr - Prev, Prev)", "0.0%", "4. النمو"),
        measure("نمو الأرباح",
                "VAR Curr = [إجمالي الأرباح]\n"
                f"VAR Prev = CALCULATE([إجمالي الأرباح], DATEADD('{T_DATE}'[{C_DATE}], -1, MONTH))\n"
                "RETURN\n    DIVIDE(Curr - Prev, Prev)", "0.0%", "4. النمو"),
    ]

    model = {
        "compatibilityLevel": 1500,
        "model": {
            "culture": "ar-EG",
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "sourceQueryCulture": "ar-EG",
            "tables": [
                {
                    "name": T_DATE,
                    "dataCategory": "Time",
                    "columns": [
                        col(C_DATE, "dateTime", fmt="yyyy-mm-dd", key=True),
                        col(C_YEAR, "int64", fmt="#,##0"),
                        col(C_QUARTER, "int64", fmt="#,##0"),
                        col(C_MONTH, "int64", fmt="#,##0"),
                        col(C_MONTHNAME, "string"),
                        col(C_YEARMONTH, "string"),
                    ],
                    "hierarchies": [{
                        "name": "التسلسل الزمني",
                        "levels": [
                            {"name": C_YEAR, "column": C_YEAR},
                            {"name": C_QUARTER, "column": C_QUARTER},
                            {"name": C_MONTHNAME, "column": C_MONTHNAME},
                            {"name": C_DATE, "column": C_DATE},
                        ],
                    }],
                    "partitions": [csv_partition(T_DATE, dates, date_types)],
                },
                {
                    "name": T_PROD,
                    "columns": [col(C_PROD, "string", key=True), col(C_CATEGORY, "string")],
                    "partitions": [csv_partition(T_PROD, products, prod_types)],
                },
                {
                    "name": T_CITY,
                    "columns": [col(C_CITY, "string", key=True), col(C_GOV, "string")],
                    "partitions": [csv_partition(T_CITY, cities, city_types)],
                },
                {
                    "name": T_SALES,
                    "columns": [
                        col(C_ORDER, "int64", fmt="#,##0", key=True),
                        col(C_DATE, "dateTime", fmt="yyyy-mm-dd"),
                        col(C_PROD, "string"),
                        col(C_CITY, "string"),
                        col(C_QTY, "int64", fmt="#,##0"),
                        col(C_PRICE, "double", fmt="#,##0.00"),
                        col(C_SALES, "double", fmt="#,##0.00"),
                        col(C_PROFIT, "double", fmt="#,##0.00"),
                        col(C_GROSS, "double", fmt="#,##0.00"),
                        col(C_FACTOR, "double", fmt="0.00"),
                        col(C_STATUS, "string"),
                    ],
                    "partitions": [csv_partition(T_SALES, fact, fact_types)],
                },
                {
                    "name": T_MEAS,
                    "columns": [col("القيمة", "int64", hidden=True)],
                    "partitions": [csv_partition(T_MEAS, pd.DataFrame({"القيمة": [1]}),
                                                 [("القيمة", "Int64.Type")])],
                    "measures": measures,
                },
            ],
            "relationships": [
                {"name": "rel_sales_date", "fromTable": T_SALES, "fromColumn": C_DATE,
                 "toTable": T_DATE, "toColumn": C_DATE},
                {"name": "rel_sales_product", "fromTable": T_SALES, "fromColumn": C_PROD,
                 "toTable": T_PROD, "toColumn": C_PROD},
                {"name": "rel_sales_city", "fromTable": T_SALES, "fromColumn": C_CITY,
                 "toTable": T_CITY, "toColumn": C_CITY},
            ],
        },
    }
    return model


# --------------------------------------------------------------------------
# Report
# --------------------------------------------------------------------------


def build_report(root: str, facts: dict) -> None:
    rep = os.path.join(root, REPORT_DIR)
    pages_root = os.path.join(rep, "definition", "pages")

    def page(folder, display, visuals):
        pdir = os.path.join(pages_root, folder)
        os.makedirs(pdir, exist_ok=True)
        wj(os.path.join(pdir, "page.json"), {
            "$schema": SCHEMA_PAGE,
            "name": folder,
            "displayName": display,
            "displayOption": "FitToPage",
            "height": PAGE_H,
            "width": PAGE_W,
            "objects": {
                "background": [{"properties": {"color": solid(PAGE_BG),
                                               "transparency": lit(0, "D")}}],
                "outspace": [{"properties": {"color": solid(PAGE_OUTSPACE),
                                             "transparency": lit(0, "D")}}],
            },
        })
        for v in visuals:
            wj(os.path.join(pdir, "visuals", v["name"], "visual.json"), v)
        return folder

    order = []

    # ============================ Overview =================================
    ov = [textbox(vid("ov", "title"), 24, 12, 1552, 56,
                  [para("لوحة المبيعات  —  نظرة عامة", 24, True, "#1F2328", "Segoe UI Semibold")]),
          textbox(vid("ov", "sub"), 24, 70, 1552, 38,
                  [para(f"{facts['orders']} طلب  •  {facts['min_date']} إلى {facts['max_date']}  •  "
                        f"إجمالي المبيعات {facts['sales']:,.0f}  •  هامش الربح {facts['margin']:.1%}",
                        13, False, "#57606A", "Segoe UI")])]

    kpis = [("إجمالي المبيعات", "إجمالي المبيعات"), ("إجمالي الأرباح", "إجمالي الأرباح"),
            ("هامش الربح", "هامش الربح"), ("عدد الطلبات", "عدد الطلبات"),
            ("متوسط قيمة الطلب", "متوسط قيمة الطلب")]
    for i, (label, mname) in enumerate(kpis):
        ov.append(kpi_card(vid("ov", "kpi", label), 24 + i * 313, 120, 300, 150, label, mname))

    ov.append(visual(
        "lineChart", vid("ov", "trend"), 24, 424, 1000, 452,
        {"Category": {"projections": [proj(f_col(T_DATE, C_YEARMONTH), T_DATE, C_YEARMONTH, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات"),
                               proj(f_meas(T_MEAS, "إجمالي الأرباح"), T_MEAS, "إجمالي الأرباح")]}},
        z=20, tab=len(ov), sort=sort_by_column(T_DATE, C_YEARMONTH),
        objects=chart_objects(show_labels=False, show_axis=True, show_legend=True),
        panel_title="المبيعات والأرباح شهرياً"))

    ov.append(visual(
        "columnChart", vid("ov", "city"), 1044, 424, 532, 452,
        {"Category": {"projections": [proj(f_col(T_CITY, C_CITY), T_CITY, C_CITY, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات")]}},
        z=21, tab=len(ov), sort=sort_by_measure(T_MEAS, "إجمالي المبيعات"),
        objects=chart_objects(show_labels=True, show_axis=False),
        panel_title="المبيعات حسب المدينة"))

    for i, (ent, prop, label) in enumerate([(T_DATE, C_YEARMONTH, "السنة والشهر"),
                                            (T_CITY, C_CITY, "المدينة"),
                                            (T_PROD, C_PROD, "المنتج")]):
        ov.append(slicer(vid("ov", "slicer", label), 24 + i * 524, 282, 504, 130, ent, prop, label))

    order.append(page("Overview", "نظرة عامة", ov))

    # ============================ Products =================================
    pr = [textbox(vid("pr", "title"), 24, 12, 1552, 56,
                  [para("تحليل المنتجات", 24, True, "#1F2328", "Segoe UI Semibold")]),
          slicer(vid("pr", "slicer"), 24, 82, 300, 224, T_PROD, C_CATEGORY, "الفئة")]

    pr.append(visual(
        "barChart", vid("pr", "bar"), 344, 82, 600, 300,
        {"Category": {"projections": [proj(f_col(T_PROD, C_PROD), T_PROD, C_PROD, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات"),
                               proj(f_meas(T_MEAS, "إجمالي الأرباح"), T_MEAS, "إجمالي الأرباح")]}},
        z=11, tab=len(pr), sort=sort_by_measure(T_MEAS, "إجمالي المبيعات"),
        objects=chart_objects(show_labels=False, show_axis=True, show_legend=True),
        panel_title="المبيعات والأرباح حسب المنتج"))

    pr.append(visual(
        "columnChart", vid("pr", "margin"), 964, 82, 612, 300,
        {"Category": {"projections": [proj(f_col(T_PROD, C_PROD), T_PROD, C_PROD, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "هامش الربح"), T_MEAS, "هامش الربح")]}},
        z=12, tab=len(pr), sort=sort_by_measure(T_MEAS, "هامش الربح"),
        objects=chart_objects(show_labels=True, show_axis=False),
        panel_title="هامش الربح حسب المنتج"))

    pr.append(visual(
        "tableEx", vid("pr", "table"), 24, 396, 1552, 480,
        {"Values": {"projections": [
            proj(f_col(T_PROD, C_PROD), T_PROD, C_PROD),
            proj(f_col(T_PROD, C_CATEGORY), T_PROD, C_CATEGORY),
            proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات"),
            proj(f_meas(T_MEAS, "إجمالي الأرباح"), T_MEAS, "إجمالي الأرباح"),
            proj(f_meas(T_MEAS, "هامش الربح"), T_MEAS, "هامش الربح"),
            proj(f_meas(T_MEAS, "إجمالي الكمية"), T_MEAS, "إجمالي الكمية"),
            proj(f_meas(T_MEAS, "عدد الطلبات"), T_MEAS, "عدد الطلبات")]}},
        z=13, tab=len(pr), objects=table_objects(12),
        panel_title="تفاصيل المنتجات"))

    order.append(page("Products", "تحليل المنتجات", pr))

    # ============================ Cities ===================================
    ci = [textbox(vid("ci", "title"), 24, 12, 1552, 56,
                  [para("تحليل المدن", 24, True, "#1F2328", "Segoe UI Semibold")])]

    ci.append(visual(
        "columnChart", vid("ci", "sales"), 24, 82, 780, 300,
        {"Category": {"projections": [proj(f_col(T_CITY, C_CITY), T_CITY, C_CITY, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات")]}},
        z=10, tab=len(ci), sort=sort_by_measure(T_MEAS, "إجمالي المبيعات"),
        objects=chart_objects(show_labels=True, show_axis=False),
        panel_title="المبيعات حسب المدينة"))

    ci.append(visual(
        "barChart", vid("ci", "profit"), 824, 82, 752, 300,
        {"Category": {"projections": [proj(f_col(T_CITY, C_CITY), T_CITY, C_CITY, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي الأرباح"), T_MEAS, "إجمالي الأرباح")]}},
        z=11, tab=len(ci), sort=sort_by_measure(T_MEAS, "إجمالي الأرباح"),
        objects=chart_objects(show_labels=True, show_axis=False),
        panel_title="الأرباح حسب المدينة"))

    ci.append(visual(
        "lineChart", vid("ci", "trend"), 24, 396, 1000, 480,
        {"Category": {"projections": [proj(f_col(T_DATE, C_YEARMONTH), T_DATE, C_YEARMONTH, True)]},
         "Series": {"projections": [proj(f_col(T_CITY, C_CITY), T_CITY, C_CITY)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات")]}},
        z=12, tab=len(ci), sort=sort_by_column(T_DATE, C_YEARMONTH),
        objects=chart_objects(show_labels=False, show_axis=True, show_legend=True),
        panel_title="اتجاه المبيعات الشهري لكل مدينة"))

    ci.append(visual(
        "tableEx", vid("ci", "table"), 1044, 396, 532, 480,
        {"Values": {"projections": [
            proj(f_col(T_CITY, C_CITY), T_CITY, C_CITY),
            proj(f_col(T_CITY, C_GOV), T_CITY, C_GOV),
            proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات"),
            proj(f_meas(T_MEAS, "إجمالي الأرباح"), T_MEAS, "إجمالي الأرباح"),
            proj(f_meas(T_MEAS, "هامش الربح"), T_MEAS, "هامش الربح")]}},
        z=13, tab=len(ci), objects=table_objects(11),
        panel_title="تفاصيل المدن"))

    order.append(page("Cities", "تحليل المدن", ci))

    # ============================ Data quality ==============================
    dm = ", ".join(facts["disc_months"]) or "-"
    mm = ", ".join(facts["markup_months"]) or "-"
    dq = [textbox(vid("dq", "title"), 24, 12, 1552, 56,
                  [para("جودة البيانات والتسعير", 24, True, "#1F2328", "Segoe UI Semibold")]),
          textbox(vid("dq", "note"), 24, 70, 1552, 40,
                  [para(f"إجمالي المبيعات لا يساوي دائماً (الكمية × سعر الوحدة): "
                        f"{facts['disc_rows']} طلباً في {dm} تُسعَّر بنسبة 45% من القيمة الاسمية (خصم)، "
                        f"و{facts['markup_rows']} طلباً في {mm} بنسبة 135% (زيادة). "
                        f"الأنماط شهرية ومنتظمة وليست أخطاء عشوائية.",
                        13, False, "#57606A", "Segoe UI")])]

    dq.append(visual(
        "columnChart", vid("dq", "status"), 24, 122, 504, 258,
        {"Category": {"projections": [proj(f_col(T_SALES, C_STATUS), T_SALES, C_STATUS, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "عدد الطلبات"), T_MEAS, "عدد الطلبات")]}},
        z=10, tab=len(dq), sort=sort_by_measure(T_MEAS, "عدد الطلبات"),
        objects=chart_objects(show_labels=True, show_axis=False),
        panel_title="عدد الطلبات حسب حالة التسعير"))

    dq.append(visual(
        "columnChart", vid("dq", "factor"), 548, 122, 504, 258,
        {"Category": {"projections": [proj(f_col(T_DATE, C_YEARMONTH), T_DATE, C_YEARMONTH, True)]},
         "Y": {"projections": [proj(f_meas(T_MEAS, "متوسط معامل التسعير"), T_MEAS, "متوسط معامل التسعير")]}},
        z=11, tab=len(dq), sort=sort_by_column(T_DATE, C_YEARMONTH),
        objects=chart_objects(show_labels=False, show_axis=True),
        panel_title="متوسط معامل التسعير شهرياً"))

    dq.append(visual(
        "columnChart", vid("dq", "compare"), 1072, 122, 504, 258,
        {"Category": {"projections": [proj(f_col(T_DATE, C_YEARMONTH), T_DATE, C_YEARMONTH, True)]},
         "Y": {"projections": [
             proj(f_meas(T_MEAS, "القيمة الاسمية الإجمالية"), T_MEAS, "القيمة الاسمية الإجمالية"),
             proj(f_meas(T_MEAS, "إجمالي المبيعات"), T_MEAS, "إجمالي المبيعات")]}},
        z=12, tab=len(dq), sort=sort_by_column(T_DATE, C_YEARMONTH),
        objects=chart_objects(show_labels=False, show_axis=True, show_legend=True),
        panel_title="القيمة الاسمية مقابل المبيعات"))

    dq.append(visual(
        "tableEx", vid("dq", "table"), 24, 396, 1552, 480,
        {"Values": {"projections": [
            proj(f_col(T_SALES, C_ORDER), T_SALES, C_ORDER),
            proj(f_col(T_SALES, C_DATE), T_SALES, C_DATE),
            proj(f_col(T_SALES, C_PROD), T_SALES, C_PROD),
            proj(f_col(T_SALES, C_CITY), T_SALES, C_CITY),
            proj(f_col(T_SALES, C_QTY), T_SALES, C_QTY),
            proj(f_col(T_SALES, C_PRICE), T_SALES, C_PRICE),
            proj(f_col(T_SALES, C_GROSS), T_SALES, C_GROSS),
            proj(f_col(T_SALES, C_SALES), T_SALES, C_SALES),
            proj(f_col(T_SALES, C_PROFIT), T_SALES, C_PROFIT),
            proj(f_col(T_SALES, C_FACTOR), T_SALES, C_FACTOR),
            proj(f_col(T_SALES, C_STATUS), T_SALES, C_STATUS)]}},
        z=13, tab=len(dq), objects=table_objects(11),
        panel_title="تفاصيل الطلبات"))

    order.append(page("DataQuality", "جودة البيانات والتسعير", dq))

    # ------------------------- report level --------------------------------
    wj(os.path.join(rep, "definition", "pages", "pages.json"), {
        "$schema": SCHEMA_PAGES,
        "pageOrder": order,
        "activePageName": order[0],
    })
    wj(os.path.join(rep, "definition", "version.json"), {
        "$schema": SCHEMA_VERSION,
        "version": "2.0.0",
    })
    wj(os.path.join(rep, "definition", "report.json"), {
        "$schema": SCHEMA_REPORT,
        "themeCollection": {
            "customTheme": {
                "name": THEME_NAME,
                "reportVersionAtImport": {"visual": "2.9.0", "report": "3.3.0", "page": "2.1.0"},
                "type": "RegisteredResources",
            }
        },
        "resourcePackages": [{
            "name": "RegisteredResources",
            "type": "RegisteredResources",
            "items": [{"name": THEME_NAME, "path": THEME_NAME, "type": "CustomTheme"}],
        }],
        "settings": {"useStylableVisualContainerHeader": True},
    })
    wj(os.path.join(rep, "StaticResources", "RegisteredResources", THEME_NAME), THEME)
    wj(os.path.join(rep, "definition.pbir"), {
        "$schema": SCHEMA_PBIR,
        "version": "4.0",
        "datasetReference": {"byPath": {"path": f"../{MODEL_DIR}"}},
    })
    wj(os.path.join(rep, ".platform"), {
        "$schema": SCHEMA_PLATFORM,
        "metadata": {"type": "Report", "displayName": "لوحة المبيعات"},
        "config": {"version": "2.0", "logicalId": "b7d4c1e2-5a93-4f60-9c81-2d6e4f0a7c53"},
    })


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="Excel or CSV file with the source data")
    ap.add_argument("--project-root", default=DEFAULT_ROOT)
    ap.add_argument("--scope", default="data", choices=["data", "all"],
                    help="'data' rebuilds data/ + model.bim only; 'all' rebuilds the whole project")
    args = ap.parse_args()

    root = os.path.abspath(args.project_root)
    fact, products, cities, dates, facts = prepare(args.source)

    data_dir = os.path.join(root, "data")
    os.makedirs(data_dir, exist_ok=True)
    for name, df in [("sales", fact), ("products", products), ("cities", cities), ("dates", dates)]:
        df.to_csv(os.path.join(data_dir, f"{name}.csv"), index=False, encoding="utf-8-sig")

    model_dir = os.path.join(root, MODEL_DIR)
    os.makedirs(model_dir, exist_ok=True)
    wj(os.path.join(model_dir, "model.bim"), build_model_bim(fact, products, cities, dates))
    wj(os.path.join(model_dir, "definition.pbism"), {
        "$schema": SCHEMA_PBISM, "version": "1.0", "settings": {},
    })
    wj(os.path.join(model_dir, ".platform"), {
        "$schema": SCHEMA_PLATFORM,
        "metadata": {"type": "SemanticModel", "displayName": "لوحة المبيعات"},
        "config": {"version": "2.0", "logicalId": "3e9a52d1-7c48-4b26-a15f-9d0c7b6e8a42"},
    })

    if args.scope == "all":
        build_report(root, facts)
        wj(os.path.join(root, f"{PROJECT}.pbip"), {
            "$schema": SCHEMA_PBIP,
            "version": "1.0",
            "artifacts": [{"report": {"path": REPORT_DIR}}],
            "settings": {"enableAutoRecovery": True},
        })

    print("facts:", json.dumps(facts, ensure_ascii=False, indent=2))
    print("rows ->", {"fact": len(fact), "products": len(products),
                      "cities": len(cities), "dates": len(dates)})
    print("scope:", args.scope, "| root:", root)


if __name__ == "__main__":
    main()
